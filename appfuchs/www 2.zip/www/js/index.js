/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

// Wait for the deviceready event before using any of Cordova's device APIs.
// See https://cordova.apache.org/docs/en/latest/cordova/events/events.html#deviceready
document.addEventListener("deviceready", onDeviceReady, false);
function onDeviceReady() {
    console.log(navigator.camera);
}
// menu burger
var sidenav = document.getElementById("mySidenav");
var openBtn = document.getElementById("openBtn");
var closeBtn = document.getElementById("closeBtn");

openBtn.onclick = openNav;
closeBtn.onclick = closeNav;

/* Set the width of the side navigation to 250px */
function openNav() {
    sidenav.classList.add("active");
}

/* Set the width of the side navigation to 0 */
function closeNav() {
    sidenav.classList.remove("active");
}

/* Caméra*/
let app = {
    init: function (){

    },
    takephoto: function (){

    },
    ftw: function (){

    }


}

// jquery formulaire

$.post('send.php',
    {
        name: 'Jean-Michel',
        email: 'jeanmich@caramail.com'
    }, function(data) {
        alert(data);
    });


$.get( "reception.html", data, function(data,status,xhr){}, dataType );


$('#searchForm').submit(function(event) {

    // Stop la propagation par défaut
    event.preventDefault();

    // Récupération des valeurs
    var $form = $(this),
        term = $form.find( "input[name='texte']" ).val(),
        url = $form.attr( "action" );

    // Envoie des données
    var posting = $.post( url, { s: term } );

    // Reception des données et affichage
    posting.done(function(data) {
        var content = $(data).find('#content');
        $('#result').empty().append(content);
    });

});


